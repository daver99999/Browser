Hi, Folks

Here It Is! The Jeff Minter�s ROX III game
for the 8K expansion Commodore Vic-20

This Zip package contains :

8k rox iii.prg ---> the Vic-20 program. You can play it with an emulator (PCVIC, VIc-20) or transfer to a real Vic20 with 8K expansion.

RoxIII.d64 ---> A .D64 disk image with the .PRG above, for VICE emulator. Also you can transfer directly to a 1541 disk with StarCommander or similar.

RoxIII Capture.jpg ----> Screenshot capture

RoxIII TapeCover.jpg ---> The original tape cover. Spanish distribution.

These files are from my original tape copy of RoxIII

-----------------------------------------------------------------------
REMEMBER. AFTER DOWNLOADING THE FILE IN A REAL VIC-20 OR EMULATOR YOU MUST TYPE "POKE44,36:RUN" TO PLAY IT.
-----------------------------------------------------------------------

Sorry for my horrible English ;-)
 
Thanks to the creators of StarCommander (Joe Fosters) and VICE (E. Perazzoli, T. Rantanen, A. Fachat, D. Sladic, A. Boose,
T. Biczo, J. Valta, J. Sonninen and T. Bretz.)

And, of course, thanks a lot, Mr.Jeff Minter!!!

++++++++++++++++++++++
Juan A. Maestre
juan_maestre@yahoo.es
Madrid - Spain
++++++++++++++++++++++