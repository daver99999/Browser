LLAMASOFT 8-BIT GAMES FOR EMULATOR USE
======================================

These game images may be distributed free of charge to anyone
who wants to use them on emulators.  Please feel free
to carry them on emulator sites or whatever.  Llamasoft
feels that software old enough to be running on emulators
is not going to be exactly generating a huge amount of
revenue, and as such the images are considered by Llamasoft
to be in the public domain, and there will be *no* legal
hassles if your site carries the images.

Enjoy!

\
(:-) - Y a K  1/12/96
/ 

llamaman@ix.netcom.com
http://www.magicnet.net/~yak/
