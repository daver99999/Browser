IMPORTANT!!

After the intro, please select the option to DISABLE FASTLOADER or the game will not load with SD2IEC!

TFW8B :)